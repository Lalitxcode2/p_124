function setup(){
    camera = createCapture(VIDEO);
    camera.size(550,600);

    canvas = createCanvas(550,500);
    canvas.position(650,120);

    posenet = ml5.poseNet(camera,modelLoaded);
    posenet.on("pose",gotPoses);

}

function modelLoaded(){
    console.log("Model Loaded");
}

function gotPoses(results){
    if(results.lenght > 0){
        console.log(results);
    }
}

function draw(){
    background('darkslategrey');
}